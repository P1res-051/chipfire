"use strict";
var __runInitializers = (this && this.__runInitializers) || function (thisArg, initializers, value) {
    var useValue = arguments.length > 2;
    for (var i = 0; i < initializers.length; i++) {
        value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
    }
    return useValue ? value : void 0;
};
var __esDecorate = (this && this.__esDecorate) || function (ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
    function accept(f) { if (f !== void 0 && typeof f !== "function") throw new TypeError("Function expected"); return f; }
    var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
    var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
    var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
    var _, done = false;
    for (var i = decorators.length - 1; i >= 0; i--) {
        var context = {};
        for (var p in contextIn) context[p] = p === "access" ? {} : contextIn[p];
        for (var p in contextIn.access) context.access[p] = contextIn.access[p];
        context.addInitializer = function (f) { if (done) throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
        var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
        if (kind === "accessor") {
            if (result === void 0) continue;
            if (result === null || typeof result !== "object") throw new TypeError("Object expected");
            if (_ = accept(result.get)) descriptor.get = _;
            if (_ = accept(result.set)) descriptor.set = _;
            if (_ = accept(result.init)) initializers.unshift(_);
        }
        else if (_ = accept(result)) {
            if (kind === "field") initializers.unshift(_);
            else descriptor[key] = _;
        }
    }
    if (target) Object.defineProperty(target, contextIn.name, descriptor);
    done = true;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __setFunctionName = (this && this.__setFunctionName) || function (f, name, prefix) {
    if (typeof name === "symbol") name = name.description ? "[".concat(name.description, "]") : "";
    return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminUsersController = void 0;
var common_1 = require("@nestjs/common");
var client_1 = require("@prisma/client");
var nanoid_1 = require("nanoid");
var jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
var roles_decorator_1 = require("../auth/roles.decorator");
var roles_guard_1 = require("../auth/roles.guard");
var AdminUsersController = function () {
    var _classDecorators = [(0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard, roles_guard_1.RolesGuard), (0, roles_decorator_1.Roles)(client_1.UserRole.ADMIN), (0, common_1.Controller)('admin/users')];
    var _classDescriptor;
    var _classExtraInitializers = [];
    var _classThis;
    var _instanceExtraInitializers = [];
    var _list_decorators;
    var _get_decorators;
    var _create_decorators;
    var _update_decorators;
    var _resetPassword_decorators;
    var AdminUsersController = _classThis = /** @class */ (function () {
        function AdminUsersController_1(users, audit) {
            this.users = (__runInitializers(this, _instanceExtraInitializers), users);
            this.audit = audit;
        }
        AdminUsersController_1.prototype.list = function () {
            return this.users.list();
        };
        AdminUsersController_1.prototype.get = function (id) {
            return this.users.getById(id);
        };
        AdminUsersController_1.prototype.create = function (req, dto) {
            return __awaiter(this, void 0, void 0, function () {
                var created, actor;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.users.create({
                                name: dto.name,
                                email: dto.email,
                                password: dto.password,
                                status: dto.status,
                                role: dto.role,
                                instanceLimit: dto.instanceLimit,
                                notes: dto.notes,
                            })];
                        case 1:
                            created = _a.sent();
                            actor = req.user;
                            return [4 /*yield*/, this.audit.log({
                                    userId: actor === null || actor === void 0 ? void 0 : actor.sub,
                                    action: 'ADMIN_USER_CREATE',
                                    entity: 'User',
                                    entityId: created.id,
                                    ipAddress: req.ip,
                                    userAgent: req.headers['user-agent'],
                                    meta: { email: created.email, role: created.role, status: created.status },
                                })];
                        case 2:
                            _a.sent();
                            return [2 /*return*/, created];
                    }
                });
            });
        };
        AdminUsersController_1.prototype.update = function (req, id, dto) {
            return __awaiter(this, void 0, void 0, function () {
                var updated, actor;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.users.update(id, {
                                name: dto.name,
                                status: dto.status,
                                role: dto.role,
                                instanceLimit: dto.instanceLimit,
                                notes: dto.notes,
                            })];
                        case 1:
                            updated = _a.sent();
                            actor = req.user;
                            return [4 /*yield*/, this.audit.log({
                                    userId: actor === null || actor === void 0 ? void 0 : actor.sub,
                                    action: 'ADMIN_USER_UPDATE',
                                    entity: 'User',
                                    entityId: updated.id,
                                    ipAddress: req.ip,
                                    userAgent: req.headers['user-agent'],
                                    meta: dto,
                                })];
                        case 2:
                            _a.sent();
                            return [2 /*return*/, updated];
                    }
                });
            });
        };
        AdminUsersController_1.prototype.resetPassword = function (req, id, body) {
            return __awaiter(this, void 0, void 0, function () {
                var newPassword, user, actor;
                var _a;
                return __generator(this, function (_b) {
                    switch (_b.label) {
                        case 0:
                            newPassword = (_a = body === null || body === void 0 ? void 0 : body.newPassword) !== null && _a !== void 0 ? _a : "Tmp@".concat((0, nanoid_1.nanoid)(10));
                            return [4 /*yield*/, this.users.resetPassword(id, newPassword)];
                        case 1:
                            user = _b.sent();
                            actor = req.user;
                            return [4 /*yield*/, this.audit.log({
                                    userId: actor === null || actor === void 0 ? void 0 : actor.sub,
                                    action: 'ADMIN_USER_RESET_PASSWORD',
                                    entity: 'User',
                                    entityId: user.id,
                                    ipAddress: req.ip,
                                    userAgent: req.headers['user-agent'],
                                    meta: { generated: !(body === null || body === void 0 ? void 0 : body.newPassword) },
                                })];
                        case 2:
                            _b.sent();
                            return [2 /*return*/, { user: user, newPassword: newPassword }];
                    }
                });
            });
        };
        return AdminUsersController_1;
    }());
    __setFunctionName(_classThis, "AdminUsersController");
    (function () {
        var _metadata = typeof Symbol === "function" && Symbol.metadata ? Object.create(null) : void 0;
        _list_decorators = [(0, common_1.Get)()];
        _get_decorators = [(0, common_1.Get)(':id')];
        _create_decorators = [(0, common_1.Post)()];
        _update_decorators = [(0, common_1.Patch)(':id')];
        _resetPassword_decorators = [(0, common_1.Post)(':id/reset-password')];
        __esDecorate(_classThis, null, _list_decorators, { kind: "method", name: "list", static: false, private: false, access: { has: function (obj) { return "list" in obj; }, get: function (obj) { return obj.list; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _get_decorators, { kind: "method", name: "get", static: false, private: false, access: { has: function (obj) { return "get" in obj; }, get: function (obj) { return obj.get; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _create_decorators, { kind: "method", name: "create", static: false, private: false, access: { has: function (obj) { return "create" in obj; }, get: function (obj) { return obj.create; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _update_decorators, { kind: "method", name: "update", static: false, private: false, access: { has: function (obj) { return "update" in obj; }, get: function (obj) { return obj.update; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(_classThis, null, _resetPassword_decorators, { kind: "method", name: "resetPassword", static: false, private: false, access: { has: function (obj) { return "resetPassword" in obj; }, get: function (obj) { return obj.resetPassword; } }, metadata: _metadata }, null, _instanceExtraInitializers);
        __esDecorate(null, _classDescriptor = { value: _classThis }, _classDecorators, { kind: "class", name: _classThis.name, metadata: _metadata }, null, _classExtraInitializers);
        AdminUsersController = _classThis = _classDescriptor.value;
        if (_metadata) Object.defineProperty(_classThis, Symbol.metadata, { enumerable: true, configurable: true, writable: true, value: _metadata });
        __runInitializers(_classThis, _classExtraInitializers);
    })();
    return AdminUsersController = _classThis;
}();
exports.AdminUsersController = AdminUsersController;
